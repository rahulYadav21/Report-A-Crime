function validate() {
    var Email = document.getElementById("Email").value;
    var password = document.getElementById("password").value;
    var validEmail = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
    if(Email==""){
        alert("Please enter Email or UIDAI");
        return false;
    }
    else if(password==""){
        alert("Please enter password");
        return false;
    }
    else if(validEmail.test(Email) == false){
        alert("Please enter valid email or UIAID");
        return false;
    }
    else if(isNaN(Email)){
        alert("Please enter your 16 digit number");
        return false;
    }
    else if(Email.length!=16){
        alert("Plese enter your 16 digit number");
        return false;
    }
    else{
        return true;
    }
}