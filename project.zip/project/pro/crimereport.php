<!doctype html>
<html>
    <head>
        <title>Report a Crime</title>
        <link rel="stylesheet" href="crimereportcss.css"/>
        <script type="text/javascript" src="crimereport.js"></script>
    </head>
<body>
<div id="border">
    <div class="header">
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a  href="crimereport.php"><img src="logo-brand.png"/></a>
        <ul>
           
            <li><b>Home</b></li>
            <li><a href="about.php">About</a></li>
            <li><a href="policeLogin.php">Police Login</a></li>
            <li><a href="DetailsofPlaces.php">Details of Places</a></li>
            <li><a href="Contect.php">Contact</a></li>
        
        </ul>
    </div>
     <div class="midel" style="background-image:url(li-crime-report.jpg);background-size: 100%">
         <u><h1>Protection of <span style="color: red">Good</span>, Destruction of <span style="color: red">Bad</span></h1></u>
         <div class="login">
            <div class="forms">
        <form action="login.php" method="post" onsubmit="return validate();">
            
                <input type="text" name="Email/UIDAI" id="Email"placeholder="Email/UIDAI"/><br /><br ><br />
            
                <input type="password" name="password" id="password" placeholder="Password"/><br /><br /><br />
            
              <span><a href="login.php" style="text-decoration: none"><input type="submit" id="submit" name="submit" value="LOG IN"/></a>
            </span>
             </form>
                <a href="singup.php" style="text-decoration: none"><input type="submit" value="SIGN UP"/></a>
                
              
             </div>
             <p><u>WOMEN POWER LINE</u> <span style="color: red;font-size:60px;">1090</span></p><br/><br/><br/>
             <p><u>DIAL</u> <span style="color: red; font-size:60px;">100</span></p>
         </div>
         
    </div>
    <div class="class">
     <div class="content" style="background-image: url(content1.jpg); background-size: 100%; height: 550px; width:101.1%">
         
         <div class="sulakhansingh"  style="background-image:url(sulakhansingh1.jpg); width:10%;margin-left:50px; border:1px solid white;height:200px;flot:left">
             </div>
        
           <div class="akhilesh"  style="background-image:url(akhilesh1.jpg); width:10%; border:1px solid white;height:200px;flot:left;margin-left:1160px;">
             
         </div>
         <br/><br/><br/><br/>
         <div class="yogi"  style="background-image:url(yogi1.jpg); width:10%; border:1px solid white;height:200px;flot:left;margin-left:1160px;">
             
         </div>
         
    </div>
         
         
    </div>
    <div class="footer">
    <p>&copy;Report a Crime.in.org</p>
    </div>
</div>
</body>
</html>