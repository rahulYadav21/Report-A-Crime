<!doctype html>
<html>
    <head>
        <title>Report a Crime</title>
        <link rel="stylesheet" href="complaintbox.css"/>
    </head>
<body>
<div id="border">
    <div class="header">
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a  href="crimereport.php"><img src="logo-brand.png"/></a>
        <ul>
           
            <li><a href="crimereport.php">Home</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="policeLogin.php">Police Login</a></li>
            <li><a href="detailsofplaces.php">Details of Places</a></li>
            <li><a href="Contect.php">Contact</a></li>
        
        </ul>
    </div>
    <div class="center" style="background-image:url(69425900-crime-wallpapers.png); height:800px;width:101%; background-size:100%; margin-top:100px;">
        <u style="color:white"><h1 style="color:red;">&nbsp;<img src="bullet_arrow.png" style="height:20px;"/>Submit Complaint Application Form</h1></u>
   <div class="loginform">
       <form action="complaint_save.php" method="post">
<table class="table" border="0" cellpadding="0" cellspacing="0" width="85%" align="center" >
    <tr>
    <th calspan="4">Submit to police station :</th>
    </tr>
    <tr height="50px">
    <td>Select District :</td>
    <td>
        <select id="SelectDistrict" name="district">
        <option value="Select District">--Select District--</option>
        <option value="Lucknow">Lucknow</option>
        <option value="unnao">unnao</option>
        <option value="Sitapur">Sitapur</option>
        <option value="Hardoi">Hardoi</option>
        <option value="Rae Bareli">Rae Bareli</option>
        <option value="Kheri">Kheri</option>
        <option value="Faizabad">Faizabad</option>
        <option value="Barabanki">Barabanki</option>
        <option value="Sultanpur">Sultanpur</option>
        <option value="Ambedkar Naga">Ambedkar Naga</option>
        <option value="Bareilly">Bareilly</option>
        <option value="Shahjahanpur">Shahjahanpur</option>
        <option value="Pilibhit">Pilibhit</option>
        <option value="Badayun">Badayun</option>
        <option value="Moradabad">Moradabad</option>
        <option value="Jyotiba Phule Nagar">Jyotiba Phule Nagar</option>
        <option value="Rampur">Rampur</option>
        <option value="Bijnor">Bijnor</option>
        <option value="Meerut">Meerut</option>
        <option value="Baghpat">Baghpat</option>
        <option value="Ghaziabad">Ghaziabad</option>
        <option value="Bulandshahr">Bulandshahr</option>
        <option value="Gautam Budh Nagar">Gautam Budh Nagar</option>
        <option value="Saharanpur">Saharanpur</option>
        <option value="Muzaffarnagar">Muzaffarnagar</option>
        <option value="Agra">Agra</option>
        <option value="Firozabad">Firozabad</option>
        <option value="Mainpuri">Mainpuri</option>
        <option value="Hathras">Hathras</option>
        <option value="Etah">Etah</option>
        <option value="Kanshi Ram Nagar (Kasganj)">Kanshi Ram Nagar (Kasganj)</option>
        <option value="Kanpur Nagar">Kanpur Nagar</option>
        <option value="Auraiya">Auraiya</option>
        <option value="South Kanpur">South Kanpur</option>
        <option value="Farrukhabad">Farrukhabad</option>
        <option value="Etawah">Etawah</option>
        <option value="Jhansi">Jhansi</option>
        <option value="Jalaun (Orai)">Jalaun (Orai)</option>
        <option value="Lalitpur">Lalitpur</option>
        <option value="Allahabad">Allahabad</option>
        <option value="Kaushambi">Kaushambi</option>
        <option value="Pratapgarh">Pratapgarh</option>
        <option value="Chitrakoot">Chitrakoot</option>
        <option value="Hamirpur">Hamirpur</option>
        <option value="Banda">Banda</option>
        <option value="Varanasi">Varanasi</option>
        <option value="Chandauli">Chandauli</option>
        <option value="Jaunpur">Jaunpur</option>
        <option value="Ghazipur">Ghazipur</option>
        <option value="Mirzapur">Mirzapur</option>
        <option value="Bhadohi">Bhadohi</option>
        <option value="Azamgarh">Azamgarh</option>
        <option value="Mau">Mau</option>
        <option value="Ballia">Ballia</option>
        <option value="Gorakhpur">Gorakhpur</option>
        <option value="Maharajganj">Maharajganj</option>
        <option value="Kushinagar">Kushinagar</option>
        <option value="Deoria">Deoria</option>
        <option value="Basti">Basti</option>
        <option value="Siddharth Nagar">Siddharth Nagar</option>
        <option value="Sant Kabir Nagar (Khalilabad)">Sant Kabir Nagar (Khalilabad)</option>
        <option value="Gonda">Gonda</option>
        <option value="Shravasti">Shravasti</option>
        <option value="Bahraich">Bahraich</option>
        </select>
        </td>
    <td>Select Police Station :</td>
        
    <td >
        <select id="SelectPoliceStation" name="selectthana">
        <option value="Select Police Station">--Select Police Station--</option>
        
        <option value="gomtinagar thana">gomtinagar thana</option>
        <option value="hazratganj thana">hazratganj thana</option>
        <option value="gonda thana">gonda thana</option>
        </select>
        </td>
    </tr>
    <tr>
    <th>Details of complaint/Information of Police :</th>
    </tr>
    <tr height="50px">
    <td>Complaint Type :</td>
        <td>
        <select id="ComplaintType" name="ComplaintType" style="width:100%">
        <option value="Complaint Type">--Select Catogory--</option>
        <option value="Complaint Against Police">Complaint Against Police</option>
        <option value="General Complaint">General Complaint</option>
        <option value="Cyber Complaint">Cyber Complaint</option>
        </select>
        </td>
    
    <td>Occurance Date :</td>
    <td><select id="date" name="date">
		<option value="Date">Date</option>
		<option value="1">1</option>
		<option value="2">2</option>
		<option value="3">3</option>
		<option value="4">4</option>
		<option value="5">5</option>
		<option value="6">6</option>
		<option value="7">7</option>
		<option value="8">8</option>
		<option value="9">9</option>
		<option value="10">10</option>
		<option value="11">11</option>
		<option value="12">12</option>
		<option value="13">13</option>
		<option value="14">14</option>
		<option value="15">15</option>
		<option value="16">16</option>
		<option value="17">17</option>
		<option value="18">18</option>
		<option value="19">19</option>
		<option value="20">20</option>
		<option value="21">21</option>
		<option value="22">22</option>
		<option value="23">23</option>
		<option value="24">24</option>
		<option value="25">25</option>
		<option value="26">26</option>
		<option value="27">27</option>
		<option value="28">28</option>
		<option value="29">29</option>
		<option value="30">30</option>
		<option value="31">31</option>
		</select>
		
		<select id="month" name="month">
		<option value="Month">Month</option>
		<option value="jsnuary">Jan</option>
		<option value="february">Feb</option>
		<option value="march">Mar</option>
		<option value="">Apr</option>
		<option value="may">May</option>
		<option value="june">Jun</option>
		<option value="july">Jul</option>
		<option value="august">Aug</option>
		<option value="september">Sep</option>
		<option value="october">Oct</option>
		<option value="november">Nov</option>
		<option value="december">Dec</option>
		</select>
		
		<select id="year" name="year">
		<option value="Year">Year</option>
		<option value="2017">2017</option>
		<option value="2016">2016</option>
		<option value="2015">2015</option>
		<option value="2014">2014</option>
		<option value="2013">2013</option>
		<option value="2012">2012</option>
		<option value="2011">2011</option>
		<option value="2010">2010</option>
		<option value="2009">2009</option>
		<option value="2008">2008</option>
		<option value="2007">2007</option>
		<option value="2006">2006</option>
		<option value="2005">2005</option>
<option value="			2004	">	2004	</option>
<option value="			2003	">	2003	</option>
<option value="			2002	">	2002	</option>
<option value="			2001	">	2001	</option>
<option value="			2000	">	2000	</option>
<option value="			1999	">	1999	</option>
<option value="			1998	">	1998	</option>
<option value="			1997	">	1997	</option>
<option value="			1996	">	1996	</option>
<option value="			1995	">	1995	</option>
<option value="			1994	">	1994	</option>
<option value="			1993	">	1993	</option>
<option value="			1992	">	1992	</option>
<option value="			1991	">	1991	</option>
<option value="			1990	">	1990	</option>
<option value="			1989	">	1989	</option>
<option value="			1988	">	1988	</option>
<option value="			1987	">	1987	</option>
<option value="			1986	">	1986	</option>
<option value="			1985	">	1985	</option>
<option value="			1984	">	1984	</option>
<option value="			1983	">	1983	</option>
<option value="			1982	">	1982	</option>
<option value="			1981	">	1981	</option>
<option value="			1980	">	1980	</option>
<option value="			1979	">	1979	</option>
<option value="			1978	">	1978	</option>
<option value="			1977	">	1977	</option>
<option value="			1976	">	1976	</option>
<option value="			1975	">	1975	</option>
<option value="			1974	">	1974	</option>
<option value="			1973	">	1973	</option>
<option value="			1972	">	1972	</option>
<option value="			1971	">	1971	</option>
<option value="			1970	">	1970	</option>
<option value="			1969	">	1969	</option>
<option value="			1968	">	1968	</option>
<option value="			1967	">	1967	</option>
<option value="			1966	">	1966	</option>
<option value="			1965	">	1965	</option>
<option value="			1964	">	1964	</option>
<option value="			1963	">	1963	</option>
<option value="			1962	">	1962	</option>
<option value="			1961	">	1961	</option>
<option value="			1960	">	1960	</option>
<option value="			1959	">	1959	</option>
<option value="			1958	">	1958	</option>
<option value="			1957	">	1957	</option>
<option value="			1956	">	1956	</option>
<option value="			1955	">	1955	</option>
<option value="			1954	">	1954	</option>
<option value="			1953	">	1953	</option>
<option value="			1952	">	1952	</option>
<option value="			1951	">	1951	</option>
<option value="			1950	">	1950	</option>
		</select></td>
    </tr>
    <tr><br />
    <td>Details :</td>
    <td colspan="3" ><textarea rows="6" style="width:40%" placeholder="----TEXT---" name="details"></textarea></td>
    </tr>
    <tr>
        <td>Suspect Details :</td>
    <td colspan="3" ><textarea rows="3" style="width:50%" placeholder="----TEXT---" name="suspectdetails"></textarea></td>
    </tr>
    <tr height="50px">
    <th>Your Details :</th>
    <tr>
    <td>Name :</td>
    <td><input type="text" name="name" placeholder="Name"style="width:97%"/></td>
    <td>Father / Husband Name :</td>
    <td><input type="text" name="fatherhusbandname" placeholder="Father / Husband Name" style="width:97%"/></td>
    </tr>
    <tr>
    <td>Sex :</td>
        <td>
        <select id="ComplaintType" name="gender" style="width:50%">
        <option value="sex">--Select--</option>
        <option value="male">Male</option>
        <option value="female">Female</option>
        </select>
        </td>

    <tr>
    <td>Identification :</td>
    <td>
    <select id="ComplaintType" name="identification" style="width:100%">
    <option value="Identification">--Select Catogory--</option>
    <option value="Passport">Passport</option>
    <option value="pancard">Pan Card</option>
    <option value="drivinglicense">Driving License</option>
    <option value="voterid">Voter Id</option>
    <option value="rationcard">Ration Card</option>
    <option value="employeecard">Employee Card</option>
    <option value="Other">Other</option>
    </select>
    </td>
    <td>Cast :</td>
    <td>
    <select id="ComplaintType" name="cast" style="width:100%">
    <option value="Cast">--Select--</option>
    <option value="General">General</option>
    <option value="OBC">OBC</option>
    <option value="SC">SC</option>
    <option value="ST">ST</option>
    </select>   
    </td>
    </tr>
    <tr>
        <td>Identification No. :</td>
        <td colspan="2" ><input type="text" name="identificationno" placeholder="Identification No." style="width:59.1%"/></td>
    
    </tr>
    <tr>
    <td>Parmanent Address</td>
    <td colspan="3" ><textarea rows="3" style="width:40%" placeholder="----TEXT---" name="address"></textarea></td>
    </tr>
    <tr>
    <td>Contect Number :</td>
    <td colspan="2" ><input type="text" name="mobile" placeholder="Contect Number" style="width:59.1%"/></td>

    </tr>
    <tr>
    <td>Email Id :</td>
    <td colspan="2" ><input type="text" name="email" placeholder="Email Id" style="width:59.1%"/></td>
    <tr id="button" height="70px">
    <td colspan="4" align="center"><input type="submit" value="Submit"/>
     <input type="submit" value="cancel"/></td>

    </tr>
    
       </table>
       </form>
    </div>
    </div>
    
            <div class="footer">
    <p>&copy;Report a Crime.in.org</p>
    </div>
</div>
</body>
</html>