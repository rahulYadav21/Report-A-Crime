<!doctype html>
<html>
    <head>
        <title>Report a Crime</title>
        <link rel="stylesheet" href="about.css"/>
    </head>
<body>
<div id="border">
    <div class="header">
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a  href="crimereport.php"><img src="logo-brand.png"/></a>
        <ul>
           
            <li><a href="crimereport.php">Home</a></li>
            <li><b>About</b></li>
            <li><a href="policeLogin.php">Police Login</a></li>
            <li><a href="detailsofplaces.php">Details of Places</a></li>
            <li><a href="Contect.php">Contact</a></li>
        
        </ul>
    </div>
     <div class="midel" style="background-image:url(default.jpg); background-size:100%; height:730px; margin-top:100px; width:100.3%;">
         <br />
	<h1>Welcome To Crime Report</h1>
	<blockquote>
        <p>
            National Crime Records Bureau, an attached office of Ministry of Home Affairs, Government 
            of India was established in 1986 with a mandate to empower Indian Police with information technology solutions and criminal intelligence to enable them to enforce the law effectively.
            The computerization of the police forces in India started in 1971. NCRB started CCIS in the 
            year 1995, CIPA in 2004 and finally CCTNS in 2009. The CCTNS connects approximately 1279
            police stations and 6000 higher offices in the country.
            <br />
            CCTNS once fully functional, will allow search for a criminal / suspect on a national data base
            apart from providing various services to the citizens through Citizen Portal.
            <br />
            In future, it is also proposed to connect Police, Courts, Prosecution, Prisons and Forensic
            Labs into an Interoperable Criminal Justice System (ICJS) for facilitating data exchange 
            between the various pillars of criminal justice system.
            <br />
            NCRB also compiles and publishes National Crime Statistics i.e. Crime in India, Accidental Deaths
            & Suicides, Prison Statistics and Finger Prints. These publications serve as principal reference 
            points by policy makers, police, criminologists, researchers and media both in India and abroad.
            <br />
            NCRB has also floated various IT based Public Services like, Vahan Samanvyay (online Motor Vehicle 
            <br />
            Matching), Talash ( matching of missing persons and dead bodies). In addition, NCRB also maintains
            <br />
            Counterfeit Currency Information and Management System (FICN) and Colour Portrait Building 
            System (CBPS).
            <br />
            NCRB has recently received “Digital India Award 2016-Silver Open Data Championship” from
            the Ministry of Electronics and Information Technology, Government of India for uploading of
            Crime Statistics since 1965 on website.
            <br />
            The Central Finger Print Bureau established in 1955, is also embedded in NCRB and is a national
            repository of all fingerprints in the country and has more than one million ten digit finger prints
            data base of criminals (both convicted and arrested), provides for search facility on FACTS 

            (FingerprintAnalysis and Criminal Tracing System). It is proposed to upgrade to NAFIS in near
            future so that police stations will be able to send finger prints/ fire queries directly online to NCRB.

            NCRB also assists various States in capacity building in the area of Finger Prints, CCTNS, Network
            security and Digital Forensics through its training centers in Delhi and Kolkata. NCRB has conducted
            more than 750 training programmes and trained approximately 16000 officers till date including
            foreign law enforcement officers (1366 foreign officers from 93 countries).
            <br />
            The Bureau looks forward to fostering of partnership with universities, researchers, NGOs and public.
        </p>
         </blockquote>
	</div>
	
    <div class="footer">
    <p>&copy;2017Report a Crime.in.org</p>
    </div>

</div>

</body>

</html>