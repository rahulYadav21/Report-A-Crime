<html>
<head>
    <title>Report a Crime</title>
    <link rel="stylesheet" href="complaint_fetch.css"/>
    </head>
    <body>
    <div id="border">
    <div class="header">
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a  href="crimereport.php"><img src="logo-brand.png"/></a>
        <ul>
           
            <li><a href="crimereport.php">Home</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="policeLogin.php">Police Login</a></li>
            <li><b>Details of Places</b></li>
            <li><a href="Contect.php">Contact</a></li>
        
        </ul>
    </div>
        <div class="fetch">
        <table border="1" style="background-color:gray; color: floralwhite; " cellpadding="0" cellspacing="0" width="150%">
        <tr>
        <th>id</th>
        <th>select_district</th>
        <th>complaint_type</th>
        <th>date</th>
        <th>details</th>
        <th>suspect_details</th>
        <th>name</th>
        <th>father_name</th>
        <th>gender</th>
        <th>identification</th>
        <th>identification_no</th>
        <th>cast</th>
        <th>parmanent_address</th>
        <th>mobile</th>
        <th>email</th>
        </tr>
<?php
include('conn.php');
$sql = "SELECT * FROM report";
$resource = mysql_query($sql);//resource of executing query
	while($data = mysql_fetch_assoc($resource)){
	?>	
        <tr>
        <td allign="center"><?php echo $data['id']?></td>
        <td allign="center"><?php echo $data['select_district']?></td>
        <td allign="center"><?php echo $data['complaint_type']?></td>
        <td allign="center"><?php echo $data['date']?></td>
        <td allign="center"><?php echo $data['details']?></td>
        <td allign="center"><?php echo $data['suspect_details']?></td>
        <td allign="center"><?php echo $data['name']?></td>
        <td allign="center"><?php echo $data['father_name']?></td>
        <td allign="center"><?php echo $data['gender']?></td>
        <td allign="center"><?php echo $data['identification']?></td>
        <td allign="center"><?php echo $data['identification_no']?></td>
        <td allign="center"><?php echo $data['cast']?></td>
        <td allign="center"><?php echo $data['parmanent_address']?></td>
        <td allign="center"><?php echo $data['mobile']?></td>
        <td allign="center"><?php echo $data['email']?></td>
        </tr>
        <?php }
        ?>
        </table>
            </div>
            <div class="footer">
    <p>&copy;Report a Crime.in.org</p>
    </div>
        </div>
   </body>
        </html>