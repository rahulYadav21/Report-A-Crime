<!doctype html>
<html>
    <head>
        <title>Report a Crime</title>
        <link rel="stylesheet" href="contect.css"/>
    </head>
<body>
<div id="border">
    <div class="header">
       &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a  href="crimereport.php"><img src="logo-brand.png"/></a>
        <ul>
            <li><a href="crimereport.php">Home</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="policeLogin.php">Police Login</a></li>
            <li><a href="detailsofplaces.php">Details of Places</a></li>
            <li><b>Contact</b></li>
        </ul>
    </div>
    <div class="midd" style="background-image: url(Homelessness-and-Crime.jpg); background-size: 100%; margin-left:0px; float:left; auto; width:100.4%; height:650px;">
        <div class="center">
            <div class="in" style="background-image:url(contactimg.png); background-size:100%; height:350px; opacity:0.7">
            
            </div>
            <div class="side">
            <h2>&nbsp;<img src="bullet_arrow.png" style="width:4%;"/>UP POLICE COMPUTER CENTRE</h2>
            <blockquote><p>FORENSIC SCIENCE LABORATORY CAMPUS,<br />
                MAHANAGAR, LUCKNOW,<br />
                UTTAR PRADESH, INDIA.</p>
            <hr style="width:50%; float:left;color:white; padding:5px; background-image:url(c00.jpg)"/><br />
            <p>Website feedback and uploading of Data feeding <br />
                Problems:<br />
                Email to: <a href="#.php" style="color:red;">uppcc-up@nic.in</a><br /><br />
                <a href="#.php" style="color:red;"> Click here for telephone</a> directories</p>
                </blockquote>
            </div>
        
        </div>
    </div>
<div class="footer">
    <p>&copy;Report a Crime.in.org</p>
    </div>
</div>
</body>
</html>
