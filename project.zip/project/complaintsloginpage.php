<!doctype html>
<html>
    <head>
        <title>Report a Crime</title>
        <link rel="stylesheet" href="complaintsloginpage.css"/>
    </head>
<body>
<div id="border">
    <div class="header">
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a  href="crimereport.php"><img src="logo-brand.png"/></a>
        <ul>
           
            <li><a href="crimereport.php">Home</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="policeLogin.php">Police Login</a></li>
            <li><a href="detailsofplaces.php">Details of Places</a></li>
            <li><a href="Contect.php">Contact</a></li>
        
        </ul>
    </div>
    <div class="tat" style="background-image: url(police-cross-stick-wallpaper-dark-tagged-wlogger-wallpapers.jpg); background-size:100%; margin-top:100px; height:550px; width:101%;">
    <u style="color:white;"><h1 style="color:red; margin-left:20px;">Different Complaint Mode</h1></u>
        <form>
        <a href="complaintbox.php"><input type="button" name="newcomplaint" value="MAKE A NEW COMPLAINT" style="background-image:url(button11.jpg);text-decoration:none;"/></a><br /><br />
        <a href="status.php"><input type="button" name="complaintstatus" value="COMPLAINT STATUS" style="background-image: url(button12.jpg);" /></a><br /><br />
            <a href="status.php"><input type="button" name="remaindcomplaint" value="REMAIND COMPLAINT" style="background-image: url(button13.jpg);"/></a>
    </form>
     </div>
        <div class="footer">
    <p>&copy;Report a Crime.in.org</p>
    </div>
</div>
</body>
</html>