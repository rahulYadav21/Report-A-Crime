<!doctype html>
<html>
    <head>
        <title>Report a Crime</title>
        <link rel="stylesheet" href="crimereportcss.css"/>
        <script type="text/javascript" src="crimereport.js"></script>
    </head>
<body>
<div id="border">
    <div class="header">
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a  href="crimereport.php"><img src="logo-brand.png"/></a>
        <ul>
           
            <li><b>Home</b></li>
            <li><a href="about.php">About</a></li>
            <li><a href="policeLogin.php">Police Login</a></li>
            <li><a href="detailsofplaces.php">Details of Places</a></li>
            <li><a href="Contect.php">Contact</a></li>
        
        </ul>
    </div>
     <div class="midel" style="background-image:url(li-crime-report.jpg);background-size: 100%">
         <u><h1>Protection of <span style="color: red">Good</span>, Destruction of <span style="color: red">Bad</span></h1></u>
         <div class="login">
            <div class="forms">
        <form action="complaintsloginpage.php" method="post" onsubmit="return validate();">
            
                <input type="text" name="Email/UIDAI" id="Email"placeholder="Email/UIDAI"/><br /><br ><br />
            
                <input type="password" name="password" id="password" placeholder="Password"/><br /><br /><br />
            
              <span><a href="complaintsloginpage.php" style="text-decoration: none"><input type="submit" id="submit" name="submit" value="LOG IN"/></a>
            </span>
             </form>
                <a href="singup.php" style="text-decoration: none"><input type="submit" value="SIGN UP"/></a>
                
              
             </div>
             <p><u>WOMEN POWER LINE</u> <span style="color: red;font-size:60px;">1090</span></p><br/><br/><br/>
             <p><u>DIAL</u> <span style="color: red; font-size:60px;">100</span></p>
         </div>
         
    </div>
    <div class="class">
     <div class="content" style="background-image: url(content1.jpg); background-size: 100%; height: 550px; width:101.1%;">
         
         <div class="tttt" style="font-size:50px; font-weight:bolder; color:white">General Information</div>
         <hr style="margin-left:36%; margin-top:-19px; margin-right:20%; padding:3px; background-color:white;border-radius:0 0 10px 0;"/>
         
         <blockquote>
            <p style="font-size:20px; color:white"><br />
         With an area of appx. 243,286 Sq.Km. and a population of over 20 Crores apporx (census 2011), Uttar Pradesh has the distinction of being the largest single Police force not only in the country but of the entire world. The Director General of UP Police commands a force of approx. 2.5 Lacs aprox. personnel spread over 75 districts, 33 armed Battalions and other specialised wings/ branches relating to Intelligence, Investigation, Anti-corruption, Technical, Training, Forensic Science etc.
          <br style="margin-top:10px;" />     
        The present police system in the country was created following the recommendation of the Police Commission headed by Mr. H.M. Court in 1860 which led to the enactment of the Police Act of 1861, which is in force even today. The same Mr. Court became the first Inspector General of Police of the then North West Province and Avadh which comprised the territory of the present state of Uttar Pradesh. The Police structure was erected in the form of the following eight organisations :
         </p>
        <ul style="font-size:20px; color:white">
        <li>Provincial Police</li>
        <li>Government Railway Police</li>
        <li>Municipal Police</li>
        <li>Cantonment Police</li>
        <li>Town Police</li>
        <li>Rural and Road Police</li>
        <li>Canal Police</li>
        <li>Barkandaj Guard (to protect the courts)</li>
        
        </ul>
         </blockquote>
    </div>
         
         
    </div>
    <div class="footer">
    <p>&copy;Report a Crime.in.org</p>
    </div>
</div>
</body>
</html>