<!doctype html>
<html>
    <head>
        <title>Report a Crime</title>
        <link rel="stylesheet" href="detailsofplaces.css"/>
    </head>
<body>
<div id="border">
    <div class="header">
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a  href="crimereport.php"><img src="logo-brand.png"/></a>
        <ul>
           
            <li><a href="crimereport.php">Home</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="policeLogin.php">Police Login</a></li>
            <li><b>Details of Places</b></li>
            <li><a href="Contect.php">Contact</a></li>
        
        </ul>
    </div>
    <div class="listing" style="background-image:url(22.jpg); background-size:100%; height:1678px; margin-bottom:-100px;">
    <table class="table" border="1" cellpadding="0" cellspacing="0" width="100%">
        <tr>
        <th>S.No.</th>
        <th>Zone</th>
        <th>S.No.</th>
        <th>Ranges</th>
        <th>S.No.</th>
        <th>Districts</th>
        </tr>
        <tr>
        <td rowspan="10" style="">1</td>
        <td rowspan="10">Lucknow</td>
        <td rowspan="6">1</td>
        <td rowspan="6">Lucknow</td>
        <td>1</td>
        <td>Lucknow</td>
        </tr>
        <tr>
        <td>2</td>
        <td>unnao</td>
        </tr>
        <tr>
        <td>3</td>
        <td>Sitapur</td>
        </tr>
        <tr>
        <td>4</td>
        <td>Hardoi</td>
        </tr>
        <tr>
        <td>5</td>
        <td>Rae Bareli</td>
        </tr>
        <tr>
        <td>6</td>
        <td>Kheri</td>
        </tr>
        <tr>
        <td rowspan="4">2</td>
        <td rowspan="4">Faizabad</td>
        <td>1</td>
        <td>Faizabad 	
        </td>
        </tr>
        <tr>
        <td>2</td>
        <td>Barabanki</td>
        </tr>
        <tr>
        <td>3</td>
        <td>Sultanpur</td>
        </tr>
        <tr>
        <td>4</td>
        <td>Ambedkar Naga</td>
        </tr>
        <tr>
        <td rowspan="8">2</td>
        <td rowspan="8">Bareilly</td>
        <td rowspan="4">1</td>
        <td rowspan="4">Bareilly</td>
        <td>1</td>
        <td>Bareilly</td>
        </tr>
        <tr>
        <td>2</td>
        <td>Shahjahanpur</td>
        </tr>
        <tr>
        <td>3</td>
        <td>Pilibhit</td>
        </tr>
        <tr>
        <td>4</td>
        <td>Badayun</td>
        </tr>
        <tr>
        <td rowspan="4">2</td>
        <td rowspan="4">Moradabad</td>
        <td>1</td>
        <td>Moradabad</td>
        </tr>
        <tr>
        <td>2</td>
        <td>Jyotiba Phule Nagar</td>
        </tr>
        <tr>
        <td>3</td>
        <td>Rampur</td>
        </tr>
        <tr>
        <td>4</td>
        <td>Bijnor</td>
        </tr>
        <tr>
        <td rowspan="7">3</td>
        <td rowspan="7">Meerut</td>
        <td rowspan="5">1</td>
        <td rowspan="5">Meerut</td>
        <td>1</td>
        <td>Meerut</td>
        </tr>
        <tr>
        <td>2</td>
        <td>Baghpat</td>
        </tr>
        <tr>
        <td>3</td>
        <td>Ghaziabad</td>
        </tr>
        <tr>
        <td>4</td>
        <td>Bulandshahr</td>
        </tr>
        <tr>
        <td>5</td>
        <td>Gautam Budh Nagar</td>
        </tr>
        <tr>
        <td rowspan="2">2</td>
        <td rowspan="2">Saharanpur</td>
        <td>1</td>
        <td>Saharanpur</td>
        </tr>
        <tr>
        <td>2</td>
        <td>Muzaffarnagar</td>
        </tr>
        <tr>
        <td rowspan="8">4</td>
        <td  rowspan="8">Agra</td>
        <td rowspan="4">1</td>
        <td rowspan="4">Agra</td>
        <td>1</td>
        <td>Agra</td>
        </tr>
        <tr>
        <td>2</td>
        <td>Mathura</td>
        </tr>
        <tr>
        <td>3</td>
        <td>Firozabad</td>
        </tr>
        <tr>
        <td>4</td>
        <td>Mainpuri</td>
        </tr>
        <tr>
        <td rowspan="4">2</td>
        <td rowspan="4">Aligarh</td>
        <td>1</td>
        <td>Aligarh</td>
        </tr>
        <tr>
        <td>2</td>
        <td>Hathras</td>
        </tr>
        <tr>
        <td>3</td>
        <td>Etah</td>
        </tr>
        <tr>
        <td>4</td>
        <td>Kanshi Ram Nagar (Kasganj)</td>
        </tr>
        <tr>
        <td rowspan="10">5</td>
        <td rowspan="10">Kanpur</td>
        <td rowspan="7">1</td>
        <td rowspan="7">Kanpur</td>
        <td>1</td>
        <td>Kanpur Nagar</td>
        </tr>
        <tr>
        <td>2</td>
        <td>Kanpur Dehat</td>
        </tr>
        <tr>
        <td>3</td>
        <td>Auraiya</td>
        </tr>
        <tr>
        <td>4</td>
        <td>South Kanpur</td>
        </tr>
        <tr>
        <td>5</td>
        <td>Kannauj</td>
        </tr>
        <tr>
        <td>6</td>
        <td>Farrukhabad</td>
        </tr>
        <tr>
        <td>7</td>
        <td>Etawah</td>
        </tr>
        <tr>
        <td rowspan="3">2</td>
        <td rowspan="3">Jhansi</td>
        <td>1</td>
        <td>Jhansi</td>
        </tr>
        <tr>
        <td>2</td>
        <td>Jalaun (Orai)</td>
        </tr>
        <tr>
        <td>3</td>
        <td>Lalitpur</td>
        </tr>
        <tr>
        <td rowspan="8">6</td>
        <td rowspan="8">Allahabad</td>
        <td rowspan="4">1</td>
        <td rowspan="4">Allahabad</td>
        <td>1</td>
        <td>Allahabad</td>
        </tr>
        <tr>
        <td>2</td>
        <td>Kaushambi</td>
        </tr>
        <tr>
        <td>3</td>
        <td>Pratapgarh</td>
        </tr>
        <tr>
        <td>4</td>
        <td>Fatehpur</td>
        </tr>
        <tr>
        <td rowspan="4">2</td>
        <td rowspan="4">Chitrakoot (Banda)</td>
        <td>1</td>
        <td>Chitrakoot</td>
        </tr>
        <tr>
        <td>2</td>
        <td>Hamirpur</td>
        </tr>
        <tr>
        <td>3</td>
        <td>Banda</td>
        </tr>
        <tr>
        <td>4</td>
        <td>Mahoba</td>
        </tr>
        <tr>
        <td rowspan="10">7</td>
        <td rowspan="10">Varanasi</td>
        <td rowspan="4">1</td>
        <td rowspan="4">Varanasi</td>
        <td>1</td>
        <td>Varanasi</td>
        </tr>
        <tr>
        <td>2</td>
        <td>Chandauli</td>
        </tr>
        <tr>
        <td>3</td>
        <td>Jaunpur</td>
        </tr>
        <tr>
        <td>4</td>
        <td>Ghazipur</td>
        </tr>
        <tr>
        <td rowspan="3">2</td>
        <td rowspan="3">Mirzapur</td>
        <td>1</td>
        <td>Mirzapur</td>
        </tr>
        <tr>
        <td>2</td>
        <td>Bhadohi</td>
        </tr>
        <tr>
        <td>3</td>
        <td>Sonbhadra</td>
        </tr>
        <tr>
        <td rowspan="3">3</td>
        <td rowspan="3">Azamgarh</td>
        <td>1</td>
        <td>Azamgarh</td>
        </tr>
        <tr>
        <td>2</td>
        <td>Mau</td>
        </tr>
        <tr>
        <td>3</td>
        <td>Ballia</td>
        </tr>
        <tr>
        <td rowspan="11">8</td>
        <td rowspan="11">Gorakhpur</td>
        <td rowspan="4">1</td>
        <td rowspan="4">Gorakhpur</td>
        <td>1</td>
        <td>Gorakhpur</td>
        </tr>
        <tr>
        <td>2</td>
        <td>Maharajganj</td>
        </tr>
        <tr>
        <td>3</td>
        <td>Kushinagar</td>
        </tr>
        <tr>
        <td>4</td>
        <td>Deoria</td>
        </tr>
        <tr>
        <td rowspan="3">2</td>
        <td rowspan="3">Basti</td>
        <td>1</td>
        <td>Basti</td>
        </tr>
        <tr>
        <td>2</td>
        <td>Siddharth Nagar</td>
        </tr>
        <tr>
        <td>3</td>
        <td>Sant Kabir Nagar (Khalilabad)</td>
        </tr>
        <tr>
        <td rowspan="4">3</td>
        <td rowspan="4">Devipatan (Gonda)</td>
        <td>1</td>
        <td>Gonda</td>
        </tr>
        <tr>
        <td>2</td>
        <td>Balrampur</td>
        </tr>
        <tr>
        <td>3</td>
        <td>Shravasti</td>
        </tr>
        <tr>
        <td>4</td>
        <td>Bahraich</td>
        </tr>
        
    </table>
        </div>
    <div class="footer">
    <p>&copy;Report a Crime.in.org</p>
    </div>
</div>
</body>
</html>