<?php
$con = mysql_connect('localhost','root','');
if($con){
    $db = mysql_select_db('complaint');
    if(!$db){
        echo 'No database found!';
    }
}
else{
    echo 'connection could not established!';
}
?>