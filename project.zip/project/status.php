<!doctype html>
<html>
    <head>
        <title>Report a Crime</title>
        <link rel="stylesheet" href="status.css"/>
    </head>
<body>
<div id="border">
    <div class="header">
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a  href="crimereport.php"><img src="logo-brand.png"/></a>
        <ul>
           
            <li><a href="crimereport.php">Home</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="policeLogin.php">Police Login</a></li>
            <li><a href="detailsofplaces.php">Details of Places</a></li>
            <li><a href="Contect.php">Contact</a></li>
        
        </ul>
    </div>
    <div class="status" style="background-image:url(10.jpg); background-size:100%; height:550px; width:101%; margin-top:100px;">
        <div class="report" style="height:400px">
        <h1>Status of Your Complaints....</h1>
            <p class="box">Complaint Id :&nbsp;&nbsp;<input type="text" name="complaintid" placeholder="Complaint Id"/><br /><br /><br />
            <input type="submit" value="Check"/>
            </p>
        </div>
    </div>
  <div class="footer">
    <p>&copy;Report a Crime.in.org</p>
    </div>
</div>
</body>
</html>