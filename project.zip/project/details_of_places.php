<!doctype html>
<html>
    <head>
        <title>Report a Crime</title>
        <link rel="stylesheet" href="details_of_places.css"/>
    </head>
<body>
<div id="border">
    <div class="header">
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a  href="crimereport.php"><img src="logo-brand.png"/></a>
        <ul>
           
            <li><a href="crimereport.php">Home</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="policeLogin.php">Police Login</a></li>
            <li><b>Details of Places</b></li>
            <li><a href="Contect.php">Contact</a></li>
        
        </ul>
    </div>
    <div class="listing">
    <tr>
        <td></td>
        </tr>
    
    </div>
    <div class="footer">
    <p>&copy;Report a Crime.in.org</p>
    </div>
</div>
</body>
</html>