function valid()  {
    var firstname = document.getElementById("firstname").value;
    var lastname = document.getElementById("lastname").value;
    var email = document.getElementById("email").value;
    var validEmail = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
    var UIDAI = document.getElementById("UIDAI").value;
    var date = document.getElementById("date").value;
    var month = document.getElementById("month").value;
    var year = document.getElementById("year").value;
    var number = document.getElementById("number").value;
    var address = document.getElementById("address").value;
    var password = document.getElementById("password").value;
   
   if(firstname==""){
       alert("Please enter your firstname");
       return false;
   }
    else if(lastname==""){
        alert("Please enter your lastname");
        return false;
    }
    else if(email==""){
        alert("Please enter your email");
        return false;
    }
    else if(UIDAI==""){
        alert("Please enter your UIDAI");
        return false;
    }
    else if(date==""){
        alert("Please enter your date");
        return false;
    }
    else if(month==""){
        alert("Please enter your month");
        return false;
    }
    else if(year==""){
        alert("Please enter your year");
        return false;
    }
    else if(number==""){
        alert("Please enter your number");
        return false;
    }
    else if(address==""){
        alert("Please enter your address");
        return false;
    }
    else if(password==""){
        alert("Please enter your password");
        return false;
    }
    
    else if(validEmail.test(Email) == false){
        alert("Please enter valid email or UIAID");
        return false;
    }
    else if(isNaN(UIDAI)){
        alert("Please enter your 16 digit UIDAI");
        return false;
    }
    else if(number.length!=16){
        alert("Plese enter your 16 digit number");
        return false;
    }
    else if(isNaN(number)){
        alert("Please enter your number");
        return false;
    }
    else if(number.length!=10){
        alert("Plese enter ten digit number");
        return false;
    }
}