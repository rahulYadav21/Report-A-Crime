<?php
include('conn.php');
$select_district = $_REQUEST['district'];
$select_thana = $_REQUEST['select_thana'];
$complaint_type = $_REQUEST['ComplaintType'];
$date = $_REQUEST['year'].'-'.$_REQUEST['month'].'-'.$_REQUEST['date'];
$details = $_REQUEST['details'];
$suspect_details = $_REQUEST['suspectdetails'];
$name = $_REQUEST['name'];
$father_name = $_REQUEST['fatherhusbandname'];
$gender = $_REQUEST['gender'];
$identification = $_REQUEST['identification'];
$cast = $_REQUEST['cast'];
$identification_no = $_REQUEST['identificationno'];
$parmanent_address = $_REQUEST['address'];
$mobile = $_REQUEST['mobile'];
$email = $_REQUEST['email'];

echo $sql = "INSERT INTO report(select_district,selectthana,Complaint_Type,date,details,suspect_details,name,father_name,gender,identification,cast,identification_no,parmanent_address,mobile,email) VALUES('$select_district','$select_thana','$complaint_type','$date','$details','$suspect_details','$name','$father_name','$gender','$identification','$cast','$identification_no','$parmanent_address','$mobile','$email')";

mysql_query($sql);
$id = mysql_insert_id();
if($id){
    echo 'Data has been saved.';
}
?>